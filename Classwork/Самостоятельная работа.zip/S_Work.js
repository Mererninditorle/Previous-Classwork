function NameInput(event) {
    event.preventDefault();
    let name = document.createElement("div");
    name.innerText = "jdklfjklfdjd";
    document.body.insertBefore(name, form); 
}